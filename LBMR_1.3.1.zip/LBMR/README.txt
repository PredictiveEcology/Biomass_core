# LBMR

A fast and large landscape biomass succession model modified from LANDIS-II.

For model usage and details, please see `LBMR.Rmd`.

